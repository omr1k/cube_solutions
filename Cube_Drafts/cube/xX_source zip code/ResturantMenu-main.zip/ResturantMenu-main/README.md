# ResturantMenu
Signle page application for resturant menu generation. 
In this workspace we are using JQURY library, Bootstrap CSS, and browser functionality localStorage. 

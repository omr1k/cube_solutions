
<h1 align="center">
  Resturant website template 👩‍🍳
</h1>
a modern looking resturant page with mobile responsiveness. made with react.js and gatsby

##  Quick start
https://riz1-lv.github.io/resturant-page/

![Screenshot](Capture.PNG)

Interactive Menu

![Screenshot](menuCapture.PNG)
1.  **Run Locally**
    
    download repo and run command
    ```shell
    npm run develop
    ```
    site is now running at http://localhost:8000


